
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
	<link rel="stylesheet" type="text/css"href="admin_page.css">
    <style>

    </style>
</head>


<body>
<div class="all">
 <div class="head">

	<a href="../index.php"><img class="logo"src="../img/logo/logo_txt.png"></a>			<!-- 링크걸기 -->
</div>
<div id="container">

	<div class="sidenav">
	<a href="list.php">관리자 페이지</p>
	<a href="user/list.php">회원 관리</a>
	<br><br>
	<a href="review/list.php">리뷰 관리</a>

	</div>

	<div class="main_view">
	<h1> 관리자 페이지입니다.</h1>
	<!-- <h2 style="text-align: center;"><a id="update_btn" href="./contents_update.php">영화, 드라마 정보 업데이트</a></h2><br><br><br>

	<h2 style="text-align: center;"> 작품 검색<br><a href="https://www.themoviedb.org/?language=ko" target='_blank'>https://www.themoviedb.org/?language=ko</a></h2><br><br>

	<h2 style="text-align: center;">디즈니플러스<br><a href="https://www.disneyplus.com/ko-kr" target='_blank'>https://www.disneyplus.com/ko-kr</a></h2><br><br>

	<h2 style="text-align: center;">왓챠<br><a href="https://watcha.com/" target='_blank'>https://watcha.com/</a></h2><br><br>

	<h2 style="text-align: center;">넷플릭스<br><a href="https://www.netflix.com/kr/" target='_blank'>https://www.netflix.com/kr/</a></h2><br><br>

	<h2 style="text-align: center;">웨이브<br><a href="https://www.wavve.com/" target='_blank'>https://www.wavve.com/</a></h2><br><br>
	-->
	</div>


	</div>
</div>

</body>
</html>